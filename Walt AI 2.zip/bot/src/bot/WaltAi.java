package bot;
import java.awt.Color;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Dimension;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JLayeredPane;
import java.awt.Panel;
import java.awt.Button;
import javax.swing.JTabbedPane;
import java.awt.CardLayout;
import java.awt.Component;

 

public class WaltAi extends JFrame {

	private static final long serialVersionUID = 1L;

	//Typing Area:
	private JTextField userTextArea = new JTextField();
	
	//Chat Area:
	final JTextArea txtWindow = new JTextArea();
	
	private JLabel label = new JLabel("");
	private final JLabel label_1 = new JLabel("");
	private final JPanel panel = new JPanel();
	private JTextField textField;
	private JTextField Password;
	

	
	public WaltAi() {
		
		setIconImage(Toolkit.getDefaultToolkit().getImage(WaltAi.class.getResource("/bot/walt ai.PNG")));
		
		//Frame 
		
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(805, 685);
		this.setVisible(true);
		this.setResizable(true);
		this.setTitle("Walt Ai\r\n");
		getContentPane().setLayout(new CardLayout(0, 0));
		
		JPanel Panel_0 = new JPanel();
		Panel_0.setBackground(Color.LIGHT_GRAY);
		getContentPane().add(Panel_0, "name_5806706242138");
		
		JLabel lblNewLabel = new JLabel("Login Page");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel.setBounds(294, 26, 107, 75);
		Panel_0.add(lblNewLabel);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setBounds(160, 111, 79, 38);
		Panel_0.add(lblPassword);
		
		Password = new JTextField();
		Password.setBounds(400, 114, 139, 30);
		Panel_0.add(Password);
		Password.setColumns(10);
		
		JButton button = new JButton("Login");
		button.setBounds(304, 208, 97, 25);
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			
				if (Password.getText().isEmpty()) {
					
					JOptionPane.showMessageDialog(null, "Wrong");
					
				}else if (Password.getText().equals("4 8 15 16 23 42")) {
						JOptionPane.showMessageDialog(null, "Success!");
						JButton Continue = new JButton("WALT AI");
						
						Continue.addActionListener(new ActionListener() {
						
							public void actionPerformed(ActionEvent e) {
						
								panel.setVisible(true);
								Panel_0.setVisible(false);
						
							}
							});
							Continue.setForeground(Color.RED);
							Continue.setFont(new Font("wATCHMEn", Font.PLAIN, 12));
							Continue.setBounds(264, 250, 100, 100);
							Panel_0.add(Continue);
						 
					} else {
						JOptionPane.showMessageDialog(null, "Please enter the numbers . . .");
					}
			}

									
			
		});
			

		
		
		Panel_0.add(button);
		
		

		
	Panel_0.setLayout(null);
		
		
		
		 

		 
		
		
		
		
		getContentPane().add(panel, "name_5806650122785");
		panel.setLayout(null);
		
		JButton btnNewButton = new JButton(" ");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnNewButton.setBounds(610, 480, 26, 25);
		panel.add(btnNewButton);
		userTextArea.setBounds(77, 503, 471, 20);
		panel.add(userTextArea);
		
		userTextArea.setFont(new Font("Tahoma", Font.PLAIN, 17));
		userTextArea.setBackground(Color.RED);
		
				userTextArea.addActionListener(new ActionListener(){
					
			public void actionPerformed(ActionEvent arg0) {
						 String  userInput = userTextArea.getText();
						txtWindow.append(">: " + userInput + "\n");
						
						
						if(userInput.contains("hi") || userInput.contains("hey")  || userInput.contains("sup") || userInput.contains("what's up the world") || userInput.contains("walt is that you?") 
								|| userInput.contains("walt is that you")   || userInput.contains("hello")   ){
						
							WaltResponse("dad it's me walt how is vincent?");
						
						}
						
						if(userInput.contains("dog") || userInput.contains("vincent")) {
							WaltResponse("how is vincent dad i miss him");
						}
						
						if(userInput.contains("dead")) {
							WaltResponse("What!!");
						}
						
						if(userInput.contains("how are you") || userInput.contains("are you ok?")) {
							WaltResponse("dad i'm running out of time, i can hear them coming");
						}
						if(userInput.contains("who is coming") || userInput.contains("who are they") ) {
							WaltResponse("the others dad . . .");
						}
						
					
						else {
							int decider = (int) (Math.random()*4+1);
							if(decider == 1){
								WaltResponse("what? I didn't get that");
						}
						else if(decider == 2){
								WaltResponse("i don't have much time what are you saying");
						}
						else if(decider == 3){
								WaltResponse("dad is that you?? give me a straight answer i cant understand you");
						}
						else if(decider == 4) {
								WaltResponse("dad is that you?? please say something . . .  please");
						}
					} 
						userTextArea.setText("");
				}
			
			});
				label.setBounds(0, 37, 803, 602);
				panel.add(label);
				
				label.setLabelFor(this);
				

				label.setIcon(new ImageIcon(WaltAi.class.getResource("/bot/walt ai.PNG")));
					txtWindow.setBounds(0, 0, 787, 638);
					panel.add(txtWindow);
					
						txtWindow.setFont(new Font("Monospaced", Font.PLAIN, 14));
						txtWindow.setEditable(false);
						txtWindow.setBackground(new Color(34, 46, 36));
						txtWindow.setForeground(Color.GREEN);
						
						
						//getContentPane().add(txtWindow);
					
					JScrollPane scrollPane = new JScrollPane();
					scrollPane.setBounds(0, 0, 787, 638);
					panel.add(scrollPane);
					scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
					scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		

	}

	
	public void WaltResponse(String s){
		txtWindow.append(">: " + s + "\n");
	}
	
	public static void main(String[] args){
		new WaltAi();
		 
		
		
		
		
		
		
		
		
		

	
	
	
	
	
	
	}
		}
 