package bot;

import javax.swing.JPanel;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


import java.awt.Color;
import java.awt.Graphics;




import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.DropMode;
import javax.swing.JLabel;
import javax.swing.ImageIcon;

public class image extends JPanel{
	private final JLabel label = new JLabel("");
	public image() {
		label.setIcon(new ImageIcon("C:\\Users\\erika\\OneDrive\\Documents\\ShareX\\Screenshots\\2018-01\\eclipse_2018-01-16_16-48-20.png"));
		label.setBackground(Color.MAGENTA);
		add(label);
	}

	
	
	
	

	  //human Area:
 
   

	public void paint(Graphics g){
    /*	
    	g.setColor(new Color(242, 229, 200));
		g.fillRect(50, 50, 800, 600);
  
		//outline of tv screen
		 g.setColor(new Color (149, 134, 130));
	     g.fillRoundRect(85, 90, 725, 500, 30, 30);
	     
		
	    //g.setColor(Color.RED);
		
	     //tv screen
	     g.setColor(new Color(34, 46, 36));
	     g.fillRoundRect(115, 135, 505, 400, 30, 150);
	    
	     //white box
	     g.setColor(new Color(225, 226, 225));
	     g.fillRect(625, 325, 170, 85);
	    
	     // three bars 
	     g.setColor(Color.BLACK);
	     g.fillRect(690, 340, 100, 10);
	     
	     g.setColor(Color.BLACK);
	     g.fillRect(690, 360, 100, 10);
	     
	     g.setColor(Color.BLACK);
	     g.fillRect(690, 380, 100, 10);
	     
	     /*Polygon polygon = new Polygon();
	     polygon.addPoint(640, 335);
	     polygon.addPoint(685, 335);
	     polygon.addPoint(625, 380);
	     polygon.addPoint(690,360);
	     polygon.addPoint(690,360);
	     polygon.addPoint(690,360);
	     polygon.addPoint(690,360);
	     polygon.addPoint(690,360);
	     //polygon.addPoint(x, y); //don't complete; fill will, draw won't
	     g.drawPolygon(polygon);*/
	    /*
	     //Octagon
	     g.setColor(Color.BLACK);
	     g.drawLine(685, 350, 685, 380);
	     g.drawLine(685, 380, 667, 390);
	     g.drawLine(685, 350, 667, 340);
	     g.drawLine(667, 390, 650, 390);
	     g.drawLine(667, 340, 650, 340);
	     g.drawLine(650, 340, 635, 350);
	     g.drawLine(635, 350, 635, 380);
	     g.drawLine(635, 380, 650, 390);
	     
	     //rectangle with circle
	     
	     g.setColor(new Color (107, 95, 92));
	     g.fillRect(630, 425, 75, 150);
	     
	     // black circle
	     g.setColor(Color.BLACK);
	     g.fillOval(660, 490, 15, 15);
	
	     //rectangle with red circle and square
	     
	     g.setColor(new Color (107, 95, 92));
	     g.fillRect(710, 425, 75, 150);
	
	     // rectangle withing a rectangle
	     g.setColor(Color.BLACK);
	     g.fillRect(742, 490, 10, 50);
	     
	     // red circle
	     g.setColor(Color.RED);
	     g.fillOval(741, 450, 10, 10);
   */
	}
	

}
