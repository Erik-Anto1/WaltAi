package bot;
/*
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import java.awt.Color;
import java.awt.Graphics;
*/



import javax.swing.JFrame;
import javax.swing.JLabel;

import java.awt.Component;
import java.awt.Image;
import java.awt.image.*;
import java.awt.BorderLayout;
import javax.swing.ImageIcon;


public class myPanel{
	private static final JLabel label = new JLabel("");
	public static void main(String[] args) {
		JFrame f = new JFrame("Walt AI");
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	
		f.setSize(1052,783);
		f.setVisible(true);
		f.setResizable(false);
		label.setIcon(new ImageIcon("C:\\Users\\erika\\OneDrive\\Documents\\ShareX\\Screenshots\\2018-01\\eclipse_2018-01-16_16-48-20.png"));
		f.getContentPane().add(label, BorderLayout.NORTH);
		
	}
}
