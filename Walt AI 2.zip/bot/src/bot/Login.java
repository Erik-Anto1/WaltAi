package bot;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Dimension;
import javax.swing.JTextField;
import javax.swing.JButton;

public class Login {

	private JFrame frame;
	private JTextField Password;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login window = new Login();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Login() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 640, 480);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 622, 433);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Login Page");
		lblNewLabel.setBounds(268, 5, 134, 59);
		lblNewLabel.setPreferredSize(new Dimension(87, 27));
		panel.add(lblNewLabel);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setBounds(186, 118, 55, 16);
		panel.add(lblPassword);
		
		Password = new JTextField();
		Password.setBounds(327, 115, 116, 22);
		panel.add(Password);
		Password.setColumns(10);
		
		JButton button = new JButton("Login");
	button.setBounds(333, 181, 97, 25);
	button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			
				if (Password.getText().isEmpty()) {
				
					JOptionPane.showMessageDialog(null, "Wrong");
				
				}else if (Password.getText().equals("4 8 15 16 23 42")) {
					
					JOptionPane.showMessageDialog(null, "Success!");
				
					JButton Continue = new JButton("Continue ?");
				
					Continue.addActionListener(new ActionListener() {
					
						public void actionPerformed(ActionEvent e) {
					
							System.exit(0);
					
						}
						});
						Continue.setBounds(333, 278, 97, 25);
						panel.add(Continue);
					} else {
						JOptionPane.showMessageDialog(null, "Please enter the numbers . . .");
					}
			}
		});
	
		panel.add(button);
		
	
	}
}
